﻿using System.Windows.Controls;

namespace пр13_14.Pages
{
    public partial class User : Page
    {
        public User()
        {
            InitializeComponent();
        }
    }
}