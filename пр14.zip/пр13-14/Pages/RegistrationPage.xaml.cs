﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace пр13_14.Pages
{
    public partial class RegistrationPage : Page
    {
        public RegistrationPage()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            string fullName = tbFullName.Text;
            string email = tbEmail.Text;
            string login = tbLogin.Text;
            string password = pbPassword.Password;
            string confirm = pbConfirmPassword.Password;

            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            if (password != confirm)
            {
                MessageBox.Show("Пароли не совпадают!");
                return;
            }

            if (password.Length < 6)
            {
                MessageBox.Show("Пароль должен быть не менее 6 символов!");
                return;
            }

            bool result = DatabaseHelper.RegisterUser(fullName, email, login, password);

            if (result)
            {
                MessageBox.Show("Регистрация успешна!");
                if (Application.Current.MainWindow is MainWindow mw)
                    mw.MainFrame.Navigate(new LoginPage());
            }
            else
            {
                MessageBox.Show("Ошибка регистрации!");
            }
        }

        private void GoToLogin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
                mw.MainFrame.Navigate(new LoginPage());
        }
    }
}